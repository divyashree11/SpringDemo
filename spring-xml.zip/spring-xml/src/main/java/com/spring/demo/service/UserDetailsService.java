package com.spring.demo.service;

import com.spring.demo.model.User;

public interface UserDetailsService {

	public String createUser(User user);
}
